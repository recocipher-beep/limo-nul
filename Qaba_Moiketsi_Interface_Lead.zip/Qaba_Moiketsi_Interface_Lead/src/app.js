(() => {
  const source = document.getElementById("source"), output = document.getElementById("output");
  const errors = document.getElementById("errors"), status = document.getElementById("status");
  const escapeHtml = value => value.replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
  function resetOutput() { errors.textContent = ""; output.innerHTML = '<tr><td colspan="5" class="empty">No output yet.</td></tr>'; }
  function compile() {
    resetOutput();
    try {
      const result = LIMOAssembler.assemble(source.value);
      if (!result.rows.length) { status.textContent = "No instructions found."; return; }
      output.innerHTML = result.rows.map(row => `<tr><td>${row.line}</td><td>${row.address}</td><td>${escapeHtml(row.source)}</td><td>${row.binary}</td><td>${row.hex}</td></tr>`).join("");
      status.textContent = `Compilation successful: ${result.rows.length} instruction(s).`;
    } catch (error) { errors.textContent = error.message; status.textContent = "Compilation failed. Correct the error and try again."; }
  }
  document.getElementById("compileBtn").addEventListener("click", compile);
  document.getElementById("clearBtn").addEventListener("click", () => { source.value = ""; resetOutput(); status.textContent = "Source cleared."; });
  document.getElementById("exampleBtn").addEventListener("click", () => {
    source.value = `; Branch and jump example\nkpnh R5, R0, 7\nkpnh R6, R0, 7\nkhl R5, R6, SAME\nkpnh R7, R0, 1\nSAME:\ntlk R1, END\nkpnh R8, R0, 2\nEND:\nkpnh R9, R0, 0x10`;
    compile();
  });
})();
