# User Guide

## Open
Open `src/index.html` in a modern web browser.

## Source format
- Use one instruction per line.
- Registers: `R0` through `R31`.
- Comments start with `;`.
- Labels are written `NAME:`.
- Branch/jump targets use the label name.
- Memory operands use `offset(base)`, e.g. `0(R10)`.
- Immediate values may be decimal or hexadecimal, e.g. `12` or `0x0C`.

## Example
```asm
kpnh R5, R0, 7
kpnh R6, R0, 5
kpn R7, R5, R6
bl R7, 0(R10)
```

## Buttons
- **Compile:** translate current source into machine code.
- **Load example:** load and compile a sample with labels.
- **Clear:** clear the source and output.

The output shows source line, byte address, instruction text, binary word, and hexadecimal word. If an error appears, fix the line mentioned and compile again.

## Limitations
The tool assembles code only. It does not run it or model processor hardware.
