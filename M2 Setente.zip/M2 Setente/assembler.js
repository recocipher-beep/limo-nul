/* LIMO assembler front end. It assembles source into 32-bit words; it does not execute it. */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.LIMOAssembler = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  // M1-derived field assignments. Verify these against the final team ISA table.
  const R = {
    kpn:  { funct3: 0, funct7: 0x00 },
    tls:  { funct3: 0, funct7: 0x20 },
    le:   { funct3: 7, funct7: 0x00 },
    kp:   { funct3: 6, funct7: 0x00 },
    kpe:  { funct3: 4, funct7: 0x00 },
    stts: { funct3: 1, funct7: 0x00 },
    stto: { funct3: 5, funct7: 0x00 }
  };
  const I = {
    kpnh: { opcode: 0x13, funct3: 0 },
    leh:  { opcode: 0x13, funct3: 7 },
    kph:  { opcode: 0x13, funct3: 6 },
    kpeh: { opcode: 0x13, funct3: 4 }
  };
  const B = {
    khl:  { funct3: 0 },
    khsl: { funct3: 1 },
    khn:  { funct3: 4 },
    khk:  { funct3: 5 }
  };

  function error(line, message) { throw new Error("Line " + line + ": " + message); }
  function reg(token, line) {
    const match = /^R(\d{1,2})$/i.exec(token);
    if (!match) error(line, "expected register R0–R31, received '" + token + "'.");
    const value = Number(match[1]);
    if (value > 31) error(line, "register '" + token + "' is outside R0–R31.");
    return value;
  }
  function integer(token, line) {
    let value;
    if (/^-?0x[0-9a-f]+$/i.test(token)) {
      const negative = token.startsWith("-");
      value = parseInt(negative ? token.slice(1) : token, 16) * (negative ? -1 : 1);
    } else if (/^-?\d+$/.test(token)) value = Number(token);
    else error(line, "expected a decimal or hexadecimal integer, received '" + token + "'.");
    if (!Number.isSafeInteger(value)) error(line, "integer is outside the supported range.");
    return value;
  }
  function signed(value, bits, line, name) {
    const min = -(2 ** (bits - 1)), max = (2 ** (bits - 1)) - 1;
    if (value < min || value > max) error(line, name + " must be between " + min + " and " + max + ".");
    return value & ((1 << bits) - 1);
  }
  function align(value, step, line, name) {
    if (value % step !== 0) error(line, name + " must be a multiple of " + step + ".");
  }
  function parseLine(raw, line) {
    const clean = raw.split(";")[0].trim();
    if (!clean) return null;
    const match = /^([A-Za-z_.$][\w.$]*):(?:\s*(.*))?$/.exec(clean);
    if (match) return { line, label: match[1], instruction: (match[2] || "").trim() };
    return { line, instruction: clean };
  }
  function parseInstruction(text, line) {
    const match = /^([A-Za-z]+)\s*(.*)$/.exec(text);
    if (!match) error(line, "could not parse instruction.");
    const mnemonic = match[1].toLowerCase();
    const args = match[2].trim() ? match[2].split(",").map(part => part.trim()) : [];
    if (args.some(arg => !arg)) error(line, "missing operand.");
    return { mnemonic, args };
  }
  function count(args, expected, line, mnemonic) {
    if (args.length !== expected) error(line, mnemonic + " expects " + expected + " operand(s).");
  }
  function memory(token, line) {
    const match = /^(-?(?:0x[0-9a-f]+|\d+))\s*\(\s*(R\d{1,2})\s*\)$/i.exec(token);
    if (!match) error(line, "use offset(base) for memory operands, for example 0(R10).");
    return { offset: integer(match[1], line), base: reg(match[2], line) };
  }
  function encodeB(offset, rs2, rs1, funct3, line) {
    align(offset, 2, line, "Branch offset");
    const x = signed(offset, 13, line, "Branch offset");
    return ((((x >>> 12) & 1) << 31) | (((x >>> 5) & 0x3f) << 25) |
      (rs2 << 20) | (rs1 << 15) | (funct3 << 12) |
      (((x >>> 1) & 0xf) << 8) | (((x >>> 11) & 1) << 7) | 0x63) >>> 0;
  }
  function encodeJ(offset, rd, line) {
    align(offset, 2, line, "Jump offset");
    const x = signed(offset, 21, line, "Jump offset");
    return (((((x >>> 20) & 1) << 31) | (((x >>> 1) & 0x3ff) << 21) |
      (((x >>> 11) & 1) << 20) | (((x >>> 12) & 0xff) << 12) |
      (rd << 7) | 0x6f) >>> 0);
  }
  function encode(item, labels, pc) {
    const line = item.line;
    const parsed = parseInstruction(item.instruction, line);
    const m = parsed.mnemonic, a = parsed.args;
    if (R[m]) {
      count(a, 3, line, m);
      const rd = reg(a[0], line), rs1 = reg(a[1], line), rs2 = reg(a[2], line), f = R[m];
      return ((f.funct7 << 25) | (rs2 << 20) | (rs1 << 15) | (f.funct3 << 12) | (rd << 7) | 0x33) >>> 0;
    }
    if (I[m]) {
      count(a, 3, line, m);
      const rd = reg(a[0], line), rs1 = reg(a[1], line), imm = signed(integer(a[2], line), 12, line, "Immediate"), f = I[m];
      return ((imm << 20) | (rs1 << 15) | (f.funct3 << 12) | (rd << 7) | f.opcode) >>> 0;
    }
    if (m === "tsl") {
      count(a, 2, line, m);
      const rd = reg(a[0], line), mem = memory(a[1], line), imm = signed(mem.offset, 12, line, "Load offset");
      return ((imm << 20) | (mem.base << 15) | (2 << 12) | (rd << 7) | 0x03) >>> 0;
    }
    if (m === "bl") {
      count(a, 2, line, m);
      const rs2 = reg(a[0], line), mem = memory(a[1], line);
      align(mem.offset, 4, line, "Word store offset");
      const imm = signed(mem.offset, 12, line, "Store offset");
      return ((((imm >>> 5) & 0x7f) << 25) | (rs2 << 20) | (mem.base << 15) | (2 << 12) | ((imm & 0x1f) << 7) | 0x23) >>> 0;
    }
    if (B[m]) {
      count(a, 3, line, m);
      const rs1 = reg(a[0], line), rs2 = reg(a[1], line);
      if (labels[a[2]] === undefined) error(line, "unknown label '" + a[2] + "'.");
      return encodeB(labels[a[2]] - pc, rs2, rs1, B[m].funct3, line);
    }
    if (m === "tlk" || m === "tl") {
      count(a, m === "tlk" ? 2 : 1, line, m);
      const rd = m === "tlk" ? reg(a[0], line) : 0, target = a[a.length - 1];
      if (labels[target] === undefined) error(line, "unknown label '" + target + "'.");
      return encodeJ(labels[target] - pc, rd, line);
    }
    if (m === "tlkr") {
      count(a, 2, line, m);
      const rd = reg(a[0], line), mem = memory(a[1], line), imm = signed(mem.offset, 12, line, "Jump-register offset");
      return ((imm << 20) | (mem.base << 15) | (rd << 7) | 0x67) >>> 0;
    }
    error(line, "unknown mnemonic '" + m + "'.");
  }
  function assemble(source) {
    const parsed = [], labels = Object.create(null);
    let pc = 0;
    String(source || "").split(/\r?\n/).forEach((raw, index) => {
      const item = parseLine(raw, index + 1);
      if (!item) return;
      if (item.label) {
        if (Object.prototype.hasOwnProperty.call(labels, item.label)) error(item.line, "duplicate label '" + item.label + "'.");
        labels[item.label] = pc;
      }
      if (item.instruction) {
        parsed.push({ line: item.line, instruction: item.instruction, pc });
        pc += 4;
      }
    });
    const rows = parsed.map(item => {
      const word = encode(item, labels, item.pc);
      return { line: item.line, address: "0x" + item.pc.toString(16).padStart(4, "0"),
        source: item.instruction, binary: word.toString(2).padStart(32, "0"),
        hex: "0x" + word.toString(16).toUpperCase().padStart(8, "0") };
    });
    return { rows, labels };
  }
  return { assemble };
});
