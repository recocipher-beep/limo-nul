# Design Document — LIMO Compiler

## 1. Purpose
The application translates LIMO assembly source into 32-bit machine-code words. It is a simple compiler/assembler interface, not a processor simulator.

## 2. Requirements
- Accept assembly source in a browser editor.
- Recognise the supported LIMO mnemonics and formats.
- Support registers R0–R31, labels, semicolon comments, decimal/hexadecimal immediates, and offset(base) memory operands.
- Display byte address, source instruction, binary word, and hexadecimal word.
- Display useful line-numbered errors.
- Run as static HTML, CSS, and JavaScript.

## 3. Architecture
- `index.html`: editor, buttons, status/error messages, output table.
- `styles.css`: responsive layout and styling.
- `assembler.js`: source parser, label resolution, operand validation, instruction encoding.
- `app.js`: UI event handlers and result rendering.

## 4. Assembly workflow
1. Remove comments and blank lines.
2. First pass: record labels and assign each instruction an address, increasing by four bytes per instruction.
3. Second pass: parse the mnemonic and operands.
4. Validate registers, operand count, immediate ranges, labels, and alignment.
5. Encode each instruction and render its 32-bit binary and hexadecimal values.

## 5. Encoding model
The implementation uses RV32I-style field positions:
- R: `funct7 | rs2 | rs1 | funct3 | rd | opcode`
- I: `imm[11:0] | rs1 | funct3 | rd | opcode`
- S: split immediate, `rs2`, `rs1`, `funct3`, split immediate, opcode
- B: split PC-relative immediate, `rs2`, `rs1`, `funct3`, split immediate
- J: split PC-relative immediate, `rd`, opcode

**Verification required:** mnemonic-to-opcode and function-field assignments in `src/assembler.js` are based on the team's earlier M1-derived material and must be compared with the final approved ISA encoding table. Do not treat this draft as verified if the approved table differs.

## 6. Error handling
The assembler reports invalid registers, incorrect operand counts, malformed memory operands, out-of-range immediates, unaligned offsets, duplicate labels, unknown labels, and unsupported mnemonics.

## 7. Out of scope
No instruction execution, register/memory simulation, pipeline, hazards, forwarding, or cycle statistics are implemented.
