# Test Plan — LIMO Compiler

## Objective
Check representative instruction encodings, label handling, and validation errors.

## Run
From the project root, run:

```sh
node tests/assembler.test.js
```

## Included cases
| Test | Expected behaviour |
|---|---|
| `kpn R7, R5, R6` | Matches expected word `0x006283B3` under the current mapping |
| `kpnh R5, R0, 1` | Matches expected word `0x00100293` under the current mapping |
| `tls R7, R5, R6` | Checks subtraction-style funct7 field |
| Hex immediate `0x10` | Accepted |
| Backward branch | Resolves label to PC-relative offset |
| R32 register | Rejected with line-numbered error |
| I-format immediate 2048 | Rejected as out of range |
| Missing branch label | Rejected |
| Unknown mnemonic | Rejected |
| Unaligned word store offset | Rejected |

## Manual interface checks
1. Open `src/index.html`.
2. Compile the default example.
3. Load and compile the second example.
4. Enter an invalid register and verify the error line.
5. Clear source and verify the output is cleared.
6. Check the interface at a narrow mobile width.

## Acceptance criteria
- Encodings match the final approved M1 ISA table.
- Invalid input produces an understandable error.
- Output words contain 32 binary digits and eight hexadecimal digits.
- Interface works in a current browser.

## Status
This file describes the test plan and included test script. It does not claim tests have been run. The team must run the script and verify all expected values before tagging the release.
