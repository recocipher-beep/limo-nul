const assert = require("assert");
const { assemble } = require("../src/assembler.js");
const hex = source => assemble(source).rows.map(row => row.hex);

assert.strictEqual(hex("kpn R7, R5, R6")[0], "0x006283B3");
assert.strictEqual(hex("kpnh R5, R0, 1")[0], "0x00100293");
assert.strictEqual(hex("tls R7, R5, R6")[0], "0x406283B3");
assert.strictEqual(hex("kpnh R5, R0, 0x10")[0], "0x01000293");
assert.strictEqual(assemble("HERE:\nkpnh R5, R0, 1\nkhl R5, R0, HERE").rows[1].hex, "0xFE028EE3");
assert.throws(() => assemble("kpnh R32, R0, 1"), /Line 1: register/);
assert.throws(() => assemble("kpnh R1, R0, 2048"), /Line 1: Immediate/);
assert.throws(() => assemble("khl R1, R2, MISSING"), /unknown label/);
assert.throws(() => assemble("unknown R1"), /unknown mnemonic/);
assert.throws(() => assemble("bl R1, 2(R2)"), /multiple of 4/);
console.log("Test script completed.");
