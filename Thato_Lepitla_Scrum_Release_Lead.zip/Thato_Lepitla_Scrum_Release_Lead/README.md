# LIMO Compiler / Assembler — M2 Package

A static browser application that translates LIMO assembly into 32-bit binary and hexadecimal machine-code words. It does not execute programs or simulate a processor pipeline.

## Run locally
1. Download and extract this folder.
2. Open `src/index.html` in a modern browser.
3. Enter assembly or click **Load example**, then click **Compile**.

No server, account, paid service or internet connection is required for local use.

## Run automated tests
Install Node.js if needed, then run from this folder:

```sh
node tests/assembler.test.js
```

The included tests cover representative encodings and error cases only. Compare the entire mnemonic/opcode/function mapping with the final approved M1 ISA before release.

## Included files
- `src/` — static browser app and assembler
- `tests/` — assembler unit tests
- `examples/` — sample `.limo` programs
- `docs/ARCHITECTURE.md` — architecture and component flow
- `docs/PIPELINE_REGISTER_DATA_MODEL.md` — state and pipeline-register contract
- `docs/INTERFACE_WIREFRAMES.md` — proposed simulator wireframes
- `docs/M2_SUBMISSION_REPORT.md` — milestone report draft and limitations
- `docs/SPRINT_NOTE_TEMPLATE.md` — fill in using actual team evidence
- `docs/TEST_PLAN.md`, `docs/USER_GUIDE.md`, `docs/DESIGN.md` — supporting documentation
- `AI_USE.md` — AI assistance disclosure
- `.github/workflows/pages.yml` — GitHub Pages deployment workflow

## GitHub Pages deployment
The included workflow publishes the contents of `src/` when pushed to `main`. In the GitHub repository, check **Settings → Pages** and select **GitHub Actions** as the build/deployment source if required. Wait for the workflow to succeed, then open the published URL. Do not claim deployment succeeded until you have tested the actual URL.

Repository listed by the project draft: https://github.com/recocipher-beep/limo-nul — verify that this is your team's correct repository before using it.

## M2 requirements checklist
- [ ] Final M1 ISA mapping verified by the team
- [ ] Architecture/block diagram reviewed
- [ ] Pipeline-register data model reviewed
- [ ] Interface wireframes reviewed
- [ ] Assembler tests run and actual output recorded
- [ ] Browser manual tests completed
- [ ] Site deployed and checked on GitHub Pages
- [ ] M2 report and sprint note updated with truthful evidence
- [ ] `m2` tag created and verified in the repository
- [ ] All members understand their contribution and acknowledge AI assistance according to course policy

**Scope warning:** This is a strong assembler plus design-document package, not a completed five-stage processor simulator. Do not claim pipeline/hazard execution or full M2 completion unless that work has been integrated and verified.
