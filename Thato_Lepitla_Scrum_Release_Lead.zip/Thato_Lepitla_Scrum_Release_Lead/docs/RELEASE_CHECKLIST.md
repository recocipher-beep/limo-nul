# Release Checklist


- [ ] Compare all mnemonic encodings with the approved M1 ISA table.
- [ ] Run `node tests/assembler.test.js` and fix failures.
- [ ] Manually test the interface in a browser.
- [ ] Ensure all group members understand and review their submitted work.
- [ ] Update documentation to reflect actual test results.
- [ ] Commit files to the group repository.
- [ ] Create an annotated Git tag and verify it exists remotely.
- [ ] Submit the repository URL and exact tag name requested by the lecturer.
- [ ] Follow the course policy for acknowledging AI assistance.
sted by the lecturer.
- [ ] Follow the course policy for acknowledging AI assistance.
