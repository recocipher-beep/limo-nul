# M2 Sprint Note

**Team:** LIMO-NUL
**Milestone:** M2 — Simulator Design
**Release/tag:** m2, https://github.com/recocipher-beep/limo-nul/releases/tag/m2
**Sprint dates:** handout period 5–11 Oct 2026; M2 completed and tagged 25 Oct 2026
**Repository/commit:** https://github.com/recocipher-beep/limo-nul, commit 6ffcdf0 (m2 release)
**Submitted by:** Thato Lepitla (@Thatosh), scrum and release lead

## Done
- ISA v1.0 frozen: "Formal LIMO ISA Specification (Frozen)" (.docx and .pdf) in the repo; LIMO_M2_Milestone_Submission.pdf section 2
- Architecture and block diagram: docs/ARCHITECTURE.md; PDF section 3
- Pipeline-register data model: docs/PIPELINE_REGISTER_DATA_MODEL.md; PDF section 4
- Interface wireframes: docs/INTERFACE_WIREFRAMES.md; PDF section 5
- Working assembler: src/assembler.js (two-pass; errors reported with line numbers), docs/DESIGN.md
- Unit tests: tests/assembler.test.js, docs/TEST_PLAN.md; sample programs examples/basic.limo and labels.limo
- Site live on GitHub Pages: https://recocipher-beep.github.io/limo-nul/ (assembled a 3-line program successfully; the three encodings were hand-checked against RISC-V)
- Tag m2 created; MIT LICENSE added (PR #35)

## Not done / known issues
- Executing five-stage pipeline, hazard unit and forwarding are M3/M4 scope and are not part of M2
- Files named in the M2 PDF that were not in the final package: src/isa.js, src/pipeline_model.js, src/ui.js, src/style.css, src/examples.js, tests/run_tests.js, tests/ref_model.js (owners to upload from their own accounts)
- M2 PDF placeholders still open: D1 feedback table, Sesotho sources, AI-use lines
- PRs #33, #34 and #35 were merged without a reviewer

## Next steps (M3: pipeline core)
- Five stages, pipeline registers and control unit
- Step/Run/Reset and register and memory views
- Upload the missing files listed above, each owner from their own account [date to agree]

## Who did what
- Ts'ebetso Jaden Lekhanya (@jadenlekhanya), ISA architect: ISA v1.0 freeze and errata
- Setente (@Setente), assembler lead: src/assembler.js, docs/DESIGN.md (issue #37)
- Lereko Thulo (@recocipher-beep), test lead: tests/assembler.test.js, docs/TEST_PLAN.md, example programs
- Tumelo Leputla (@TumeloLeputla2006), pipeline and hazard-unit lead: docs/ARCHITECTURE.md, docs/PIPELINE_REGISTER_DATA_MODEL.md, block diagram
- Qaba Moiketsi, interface lead: src/index.html, src/app.js, src/styles.css, docs/INTERFACE_WIREFRAMES.md, docs/USER_GUIDE.md
- Thato Lepitla (@Thatosh), scrum and release lead: sprint note and M2 PDF (PR #33, #34), LICENSE (PR #35), release m2, reviewed and merged the M1 PDF (PR #11), issues #36 and #37, README, AI_USE.md, docs/M2_SUBMISSION_REPORT.md, docs/RELEASE_CHECKLIST.md

## Evidence
- Test command and actual output: `node tests/assembler.test.js` → `Test script completed.` (exit code 0, no assertion failed; run on the packaged copy of the tests, Node v22)
- GitHub Pages URL checked on: 25 Oct 2026, about 21:16 (assembler page loaded and assembled 3 lines)
- Pull requests/reviews: https://github.com/recocipher-beep/limo-nul/pull/33, /34, /35, /11 (PR #11 approved by Thatosh)
