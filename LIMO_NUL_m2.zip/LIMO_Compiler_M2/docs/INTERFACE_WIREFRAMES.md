# LIMO M2 — Interface Wireframes

These wireframes define the proposed arrangement and responsibilities of the main views. They are layout specifications, not screenshots of a completed pipeline simulator.

## Main simulator screen

```text
+--------------------------------------------------------------------------------+
| LIMO PROCESSOR SIMULATOR                              Help / English / Sesotho |
+--------------------------------------------------------------------------------+
| Assembly editor                         | Machine code                          |
| [Open .limo] [Save] [Assemble]          | Address | Binary | Hex | Source       |
|                                        | ...                                    |
|                                        |                                        |
+----------------------------------------+----------------------------------------+
| [Step] [Run] [Pause] [Reset] [Step Back] [Forwarding ON/OFF] [Breakpoint]       |
+--------------------------------------------------------------------------------+
| IF: Fetch | ID: Decode | EX: Execute | MEM: Memory | WB: Write Back             |
| Instruction and PC shown in each stage; invalid slots shown as bubbles          |
+--------------------------------------------------------------------------------+
| Datapath / forwarding paths                 | Control signals / hazard messages   |
| ALU inputs, ALU result, mux values          | RegWrite, MemRead, MemWrite, etc.   |
| Highlight active path and values            | RAW, load-use, branch flush          |
+---------------------------------------------+--------------------------------------+
| Register file (Sesotho names)               | Data memory                          |
| R0 ... R31; changed values highlighted      | Address / value; changed values      |
+---------------------------------------------+--------------------------------------+
| Cycle: __ | Retired: __ | CPI: __ | Stalls: __ | Flushes: __ | Trace / narration |
+--------------------------------------------------------------------------------+
```

## Required screen behaviours
- **Assemble:** show one machine-code row per instruction and readable errors with source line numbers.
- **Step:** advance exactly one clock cycle.
- **Run/Pause:** start and stop repeated stepping without blocking the browser UI.
- **Reset:** return to the initial program state.
- **Step Back:** restore a previously saved state if this feature is implemented; otherwise do not display an enabled control.
- **Forwarding toggle:** make the forwarding effect and cycle cost observable when hazard logic is integrated.
- **Breakpoints:** pause before or at a configured instruction address, with behaviour documented.
- **Views:** all panels render from the same state object; colour must not be the only way to convey information.

## Scope note
The current assembler-only web app implements the source editor, compile, clear, example and output/error panel. The pipeline, datapath, control, hazard and statistics panels are future integration targets.
