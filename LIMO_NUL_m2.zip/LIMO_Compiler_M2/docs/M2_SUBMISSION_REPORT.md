# CS3520 LIMO Project — Milestone 2 Submission Report

**Milestone:** M2 — Simulator design  
**Team:** LIMO-NUL (confirm exact team name)  
**Repository:** https://github.com/recocipher-beep/limo-nul (confirm repository and permissions before submission)  
**Release tag:** `m2` (create and verify this tag in the actual repository before claiming submission)  
**Prepared:** 25 October 2026

## 1. Objective
M2 freezes the ISA after design-review feedback and establishes the simulator architecture, pipeline-register data model, interface wireframes, a working assembler with unit tests, and a live static site on GitHub Pages.

## 2. Implemented in this package
- Browser-based static assembler interface.
- Two-pass assembly workflow for label addresses and instruction encoding.
- Output of source line, byte address, 32-bit binary word and hexadecimal word.
- Validation for supported mnemonics, register ranges, operand counts, immediates, memory operand syntax, duplicate labels, unknown labels and alignment.
- Sample programs, Node.js test script, user guide, test plan and AI-use disclosure.

## 3. Design artefacts
- `docs/ARCHITECTURE.md`: component architecture and data flow.
- `docs/PIPELINE_REGISTER_DATA_MODEL.md`: state object and four pipeline-register contracts.
- `docs/INTERFACE_WIREFRAMES.md`: main screen layout and expected control behaviours.
- `docs/DESIGN.md`: assembler architecture and encoding model.

## 4. Testing
Run `node tests/assembler.test.js` from the project root. The test script currently checks representative encodings, label resolution and invalid input. The test scope is limited; passing this script does not prove all instructions or the pipeline are correct. Record the actual command output and verify every mapping against the final frozen M1 ISA before release.

## 5. Limitations and outstanding verification
- Opcode and function-field assignments must be checked against the final approved M1 ISA table.
- This package does not implement the executing five-stage pipeline, control decoder, hazard unit, forwarding, live datapath/control visualisations or cycle statistics.
- GitHub Pages deployment, repository release tag, team commits, pull-request reviews and course submission have not been verified by this package.
- Confirm that the final submission site is live and works from a fresh browser session.

## 6. Conclusion
This package provides the assembler deliverable and supporting M2 design artefacts. It should be submitted as the complete M2 milestone only after the team confirms the ISA encodings, integrates any required pipeline work, verifies the deployed site, and completes the course's release and submission process. Do not remove this limitations section unless the outstanding items have actually been completed and tested.
