# LIMO M2 — Simulator Architecture and Block Diagram

## Purpose
This document records the proposed static-browser architecture for the LIMO project. The assembler is implemented in this package; the pipeline engine and visualisations are described as design interfaces and must be integrated and verified by the team.

## Component flow

```mermaid
flowchart TD
    A[Assembly editor / open .limo] --> B[Assembler: parse and validate]
    B -->|errors with source line| C[Error panel]
    B -->|32-bit instruction words| D[Instruction memory / program image]
    D --> E[Five-stage pipeline core]
    E --> F[Pipeline state: PC, registers, memories, pipeline registers]
    F --> G[UI: stages, datapath, control, hazards, statistics]
    H[Step / Run / Pause / Reset / Breakpoints] --> E
    I[Unit tests and reference model] --> B
    I --> E
```

## Responsibilities
- **Editor:** accepts assembly source and supports loading/saving `.limo` text.
- **Assembler:** performs label pass, instruction validation and 32-bit encoding. It does not execute instructions.
- **Program image / instruction memory:** stores assembled words by byte address.
- **Pipeline core:** advances the IF, ID, EX, MEM and WB stages once per cycle.
- **Pipeline registers:** hold values between adjacent stages.
- **State model:** stores all state required for deterministic stepping and tracing.
- **UI:** displays current state; it should render from the state returned by the core, not maintain a second copy of processor state.
- **Tests/reference model:** compare machine-code words and expected processor outcomes.

## Integration contract
The assembler returns `{ rows, labels }`. Each row includes `line`, `address`, `source`, `binary`, and `hex`. The pipeline integration layer should convert each row's hexadecimal word to a 32-bit integer and load it into instruction memory. The pipeline core should expose a deterministic `step(state)` interface returning a new state and a trace record. This interface is a design recommendation, not a claim that the pipeline core is included in this assembler package.

## Important scope note
This package contains a working assembler interface, tests and M2 design documents. It does not yet contain a complete executing five-stage processor. Before claiming the full simulator is complete, integrate and test the pipeline core, control decoder, hazard/forwarding unit, register/memory views and execution controls.
