# M2 Sprint Note — Complete Before Submission

**Release/tag:** m2 (verify actual tag)  
**Sprint dates:** [enter actual dates]  
**Repository/commit:** [paste verified URL and commit hash]

## Done
- [List only work completed and verified.] 

## Not done / known issues
- [List any incomplete requirements and blockers.] 

## Next steps
- [List concrete actions, owners and target dates.] 

## Who did what
- [Member name/handle] — [specific files, commits, pull requests and review evidence]
- [Member name/handle] — [specific files, commits, pull requests and review evidence]

## Evidence
- Test command and actual output: [paste]
- GitHub Pages URL checked on: [date/time]
- Pull requests/reviews: [links]

Do not invent contribution records, test results, dates, release tags or deployment evidence.
