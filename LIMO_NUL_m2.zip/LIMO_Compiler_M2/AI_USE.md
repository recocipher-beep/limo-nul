1. AI was used to help understand milestone 2
2. Was also used to implement programming languages such as Javascript, HTML, Yaml, and CSS which helped to build the interface
