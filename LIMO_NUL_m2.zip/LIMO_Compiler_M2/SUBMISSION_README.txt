LIMO M2 package

1. Open src/index.html for the browser assembler.
2. Run tests with: node tests/assembler.test.js
3. Review docs/M2_SUBMISSION_REPORT.md and all docs in docs/.
4. Verify opcode/function fields against the final M1 ISA.
5. Deploy using .github/workflows/pages.yml and test the live GitHub Pages URL.
6. Complete docs/SPRINT_NOTE_TEMPLATE.md using real team evidence.
7. Create/verify the m2 tag only after review.

Important: the current package does not include an executing pipeline/hazard simulator.
